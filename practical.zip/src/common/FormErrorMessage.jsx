import React from "react";
const FormErrorMessage = (props) => {
    return <div className={"text-rose-500"}>{props.children}</div>;
};
export default FormErrorMessage;